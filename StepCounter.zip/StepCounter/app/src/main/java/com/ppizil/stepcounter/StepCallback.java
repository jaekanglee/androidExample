package com.ppizil.stepcounter;

public interface StepCallback {

    void onStepCallback(int step);
    void onUnbindService();
}
